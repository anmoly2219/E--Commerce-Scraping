import scrapy
from scrapy.crawler import CrawlerProcess
from django.core.management.base import BaseCommand
from scraper_app.models import Product

# Replace with your ScraperAPI key
API_KEY = "3cb5771e4423831db65f1c21c043c237"


class EbaySpider(scrapy.Spider):
    name = "ebay"
    allowed_domains = ["ebay.com"]
    start_urls = [
        f"http://api.scraperapi.com/?api_key={API_KEY}&url=https://www.ebay.com/sch/i.html?_nkw=laptops"
    ]

    def parse(self, response):
        for item in response.css(".s-item"):
            title = item.css(".s-item__title::text").get()
            price = item.css(".s-item__price::text").get()
            url = item.css(".s-item__link::attr(href)").get()

            if title and price:
                # Save to the database
                product, created = Product.objects.get_or_create(
                    name=title.strip(),
                    price=price.strip(),
                    url=url.strip(),
                )
                # Print a message for debugging
                if created:
                    print(f"Saved product: {title.strip()} - {price.strip()}")

        # Pagination
        next_page = response.css(".pagination__next::attr(href)").get()
        if next_page:
            yield scrapy.Request(
                url=f"http://api.scraperapi.com/?api_key={API_KEY}&url={next_page}",
                callback=self.parse,
            )


class Command(BaseCommand):
    help = "Run the Scrapy spider to scrape eBay products"

    def handle(self, *args, **kwargs):
        self.stdout.write("Starting the eBay scraper...")
        process = CrawlerProcess(settings={
            "USER_AGENT": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        })
        process.crawl(EbaySpider)
        process.start()  # Start the crawling process
        self.stdout.write(self.style.SUCCESS("Scraping completed successfully!"))
